package com.jemgroup.unicab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnicabApplicationTests {

	@Test
	void contextLoads() {
	}

}
