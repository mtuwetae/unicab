package com.jemgroup.unicab.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VehicleDTO {

    private String registrationPlates;
    private String route;
    private String model;
}
