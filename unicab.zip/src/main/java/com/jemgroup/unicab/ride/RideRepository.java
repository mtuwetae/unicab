package com.jemgroup.unicab.ride;

import com.jemgroup.unicab.ride.Ride;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RideRepository extends JpaRepository<Ride, Long> {


}
