package com.jemgroup.unicab.exception;

public class DuplicateUsernameException extends RuntimeException{
}
