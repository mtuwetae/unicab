package com.jemgroup.unicab.exception;

public class DuplicateEmailException extends RuntimeException{
}
